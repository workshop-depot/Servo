﻿using Servo;

namespace $safeprojectname$
{
    static class App
    {
        static void Main(string[] args)
        {
            new $safeprojectname$Service().Run();
        }
    }
}
