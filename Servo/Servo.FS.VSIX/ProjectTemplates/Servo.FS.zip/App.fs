﻿open $safeprojectname$
open Servo.Toolbox

[<EntryPoint>]
let main argv = 
    (new $safeprojectname$Service()).Run(false)
    0 
